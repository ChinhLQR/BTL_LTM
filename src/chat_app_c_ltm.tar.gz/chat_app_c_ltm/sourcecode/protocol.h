#ifndef _PROTOCOL_H_
#define _PROTOCOL_H_

#include <stdio.h>

char* get_code_101(char* success_message);
char* get_code_102(char* error_message);
char* get_code_201();
char* get_code_205(char* error_message);

#endif