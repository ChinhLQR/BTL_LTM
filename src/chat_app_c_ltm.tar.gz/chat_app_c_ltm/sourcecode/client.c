/*
* @Author: GiapMinhCuong-20140539
* @Date:   2017-11-01 02:11:19
* @Last Modified by:   GiapMinhCuong-20140539
* @Last Modified time: 2017-11-02 01:11:30
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>

#define SERVER_IP "127.0.0.1"
#define SERVER_PORT 8484
#define MESSAGE_LENGTH 300

static int send_message(int server, char* message) {
	ssize_t sent_length;
	sent_length = send(server, message, strlen(message), 0);
	printf("INFO: Sent %d byte(s)\n", (int)(sent_length));
	return (int)sent_length;
}

int connect_server(char* server_ip, int port) {
	// 1 Tao socket
	int server = socket(AF_INET, SOCK_STREAM, 0);
	if (server < 0) {
		printf("ERROR: socket()!\n");
		return 1;
	}

	// 2 Connect
	// 2.1 Tao server_address
	struct sockaddr_in server_address;
	server_address.sin_family = AF_INET;
	// cach 2 su dung inet_addr. Method nay khong duoc khuyen khich
	//server_address.sin_addr.s_addr = inet_addr(server_ip);
	inet_aton(server_ip, &(server_address.sin_addr));
	server_address.sin_port = htons(port);

	// 2.2 Connect
	int connect_result = connect(server, (struct sockaddr*)&server_address, sizeof(server_address));
	if (connect_result < 0) {
		printf("ERROR: connect()\n");
	}
	return server;
}

int main(int argc, char* argv[]) {

	int server = connect_server("127.0.0.1", 8484);

	// 3 Send message
	char message[MESSAGE_LENGTH];
	printf("Type message: ");
	while (gets(message) != NULL) {
		if (strcmp(message, "###") == 0) {
			break;
		}
		send_message(server, message);
		bzero(message, MESSAGE_LENGTH);
		if(recv(server, message, MESSAGE_LENGTH, 0) >= 0) {
			printf("Message from server: \"%s\"\n", message);
		}
		printf("Type message: ");
	}

	close(server);
	printf("INFO: Done!\n");

	return 0;
}