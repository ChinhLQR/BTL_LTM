#ifndef _ANALYSER_H_
#define _ANALYSER_H_

#include "linked_list.h"

char* sub_string(char* source, int from, int to);
List extract_message_to_list(char* message);

void extract_user_info(char* message, char* username, char* password);

#endif