#include "protocol.h"

#include <stdlib.h>
#include <string.h>
#include "constant.h"

char* get_code_101(char* success_message) {
	char* code = malloc(MAX_STRING_LENGTH_PROTOCOL);
	code[0] = 0;
	strcat(code, "101|");
	strcat(code, success_message);
	return code;
}

char* get_code_102(char* error_message) {
	char* code = malloc(MAX_STRING_LENGTH_PROTOCOL);
	code[0] = 0;
	strcat(code, "102|");
	strcat(code, error_message);
	return code;
}

char* get_code_201() {
	char* code = malloc(MAX_STRING_LENGTH_PROTOCOL);
	strcpy(code, "201");
	return code;
}

char* get_code_205(char* error_message) {
	char* code = malloc(MAX_STRING_LENGTH_PROTOCOL);
	code[0] = 0;
	strcat(code, "205|");
	strcat(code, error_message);
	return code;
}