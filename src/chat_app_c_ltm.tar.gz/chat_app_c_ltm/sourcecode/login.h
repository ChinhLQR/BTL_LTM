#ifndef _LOGIN_H_
#define _LOGIN_H_

int login(char* username, char* password);

#endif