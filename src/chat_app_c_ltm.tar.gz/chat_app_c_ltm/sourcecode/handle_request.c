#include "handle_request.h"

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "constant.h"
#include "sign_up.h"
#include "helper.h"
#include "analyser.h"
#include "protocol.h"
#include "login.h"

void on_client_connected(int client, struct sockaddr_in client_address) {
	printf("HANDLE_REQUEST_CONNECTED\n");
}

void on_client_send_message(int client, char* message, int message_length, struct sockaddr_in client_address) {
	printf("HANDLE_REQUEST_SEND_MESSAGE\n");
	char* header = get_header(message);

	if (strcmp(header, SIGN_UP) == 0 && count_message_tokens(message) == SIGN_UP_NUM_TOKENS) {
		printf("INFO: Got a request for signing up\n");
		handle_sign_up(client, message, client_address);
	}
	else if(strcmp(header, LOG_IN) == 0 && count_message_tokens(message) == LOG_IN_NUM_TOKENS) {
		printf("INFO: Got a request for logging in\n");
		handle_login(client, message, client_address);
	}
}

void on_client_disconnected(int client, struct sockaddr_in client_address) {
	printf("HANDLE_REQUEST_DISCONNECTED\n");
}

char* get_header(char* message) {
	printf("Start checking header\n");
	int len = strlen(message);
	char tmp[len+1];
	strcpy(tmp, message);

	char* header = strtok(tmp, SEPARATOR);
	printf("HEADER = \"%s\"\n", header);
	printf("Finish checking header\n");
	return header;
}

int count_message_tokens(char* message) {
	printf("Start counting message tokens\n");
	List list = extract_message_to_list(message);
	printf("Finish counting message tokens\n");
	return count_nodes(list);
}

// extract information from sign up message
void handle_sign_up(int client, char* message, struct sockaddr_in client_address) {
	printf("INFO: Started handle signing up for client %d\n", client);

	char* username = (char*)malloc(MAX_STRING_LENGTH_TOKEN);
	char* password = (char*)malloc(MAX_STRING_LENGTH_TOKEN);

	extract_user_info(message, username, password);

	int isOk = sign_up(username, password);
	if(!isOk) {
		printf("FAILED: Signing up is not successful\n");
		printf(" ->username = \"%s\"\n", username);
		printf(" ->password = \"%s\"\n", password);

		// respond code to client
		char* code_102 = get_code_102("Signing up is failed");
		send_message(client, code_102);
		free(code_102);
	} else {
		printf("SIGNUP: Signing up is successful\n");
		printf(" ->username = \"%s\"\n", username);
		printf(" ->password = \"%s\"\n", password);

		// respond code to client
		char* code_101 = get_code_101("Signing up is successful");
		send_message(client, code_101);
		free(code_101);
	}

	free(username);
	free(password);
}

// extract information from login message
void handle_login(int client, char* message, struct sockaddr_in client_address) {
	printf("INFO: Started handle logging in for client %d\n", client);

	char* username = (char*)malloc(MAX_STRING_LENGTH_TOKEN);
	char* password = (char*)malloc(MAX_STRING_LENGTH_TOKEN);

	extract_user_info(message, username, password);
	int isOk = login(username, password);

	if(!isOk) {
		printf("FAILED: Logging in is not successful\n");
		printf(" ->username = \"%s\"\n", username);
		printf(" ->password = \"%s\"\n", password);

		// respond code to client
		char* code_205 = get_code_205("Logging in is failed");
		send_message(client, code_205);
		free(code_205);
	} else {
		printf("SIGNUP: Logging in is successful\n");
		printf(" ->username = \"%s\"\n", username);
		printf(" ->password = \"%s\"\n", password);

		// respond code to client
		char* code_201 = get_code_201();
		send_message(client, code_201);
		free(code_201);
	}

	free(username);
	free(password);
}
