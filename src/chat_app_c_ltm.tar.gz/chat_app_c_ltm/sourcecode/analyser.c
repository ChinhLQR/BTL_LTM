#include "analyser.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "constant.h"
#include "linked_list.h"

List extract_message_to_list(char* message) {
	List list = create_list();
	int len = strlen(message);
	int from = 0, to = 0, i = 0;
	char separator[2] = SEPARATOR;
	for(i=0; i<len; i++) {
		if(i == 0 || message[i-1] == separator[0]) {
			from = i;
		}
		if (i == len-1 || message[i+1] == separator[0]) {
			to = i;
			char* token = sub_string(message, from, to);
			add_node(&list, create_node(token));
		}
	}
	return list;
}

void extract_user_info(char* message, char* username, char* password) {
	// int timestamp = time(NULL);
	// char* s_timestamp = malloc(20);
	// sprintf(s_timestamp, "%u", timestamp);
	// strcpy(username, "gminhcuong");
	// strcat(username, s_timestamp);
	// strcpy(password, "123456");

	List list = extract_message_to_list(message);
	char* _username = get_node_string(2, list);
	char* _password = get_node_string(3, list);

	strcpy(username, _username);
	strcpy(password, _password);
	
	free(_username);
	free(_password);

}

char* sub_string(char* source, int from, int to) {
	int source_len = strlen(source);
	int i = 0;
	int dest_len = to - from + 1;
	char* dest = malloc(dest_len + 1);
	for (i = 0; i < dest_len; i++) {
		dest[i] = source[i + from];
	}
	dest[i] = 0;
	return dest;
}