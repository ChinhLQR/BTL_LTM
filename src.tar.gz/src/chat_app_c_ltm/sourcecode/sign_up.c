#include "sign_up.h"
#include "constant.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "database.h"

int sign_up(char* username, char* password) {
	// create sql query
	char* sql = (char*)malloc(MAX_STRING_LENGTH_SQL);
	strcat(sql, "INSERT INTO users(username, password) VALUES ('");
	strcat(sql, username);
	strcat(sql, "', '");
	strcat(sql, password);
	strcat(sql, "');");

	return insert_query(sql);
}