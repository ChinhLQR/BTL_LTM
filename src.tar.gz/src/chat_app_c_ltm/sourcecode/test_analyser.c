#include <stdio.h>
#include "analyser.h"
#include <string.h>

int main(int argc, char const *argv[])
{
	
	char message[] = "SGNU|gminhcuong|123456";
	strcpy(message, "201");
	List list = extract_message_to_list(message);
	printf("count = %d\n", count_nodes(list));
	print_list(list);
	printf("Node1 = %s\n", get_node_string(1, list));
	return 0;
}