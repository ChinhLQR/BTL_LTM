#ifndef _SIGN_UP_H_
#define _SIGN_UP_H_

int sign_up(char* username, char* password);

#endif