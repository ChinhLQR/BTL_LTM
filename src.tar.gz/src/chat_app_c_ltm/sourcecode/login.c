#include "login.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "constant.h"
#include "database.h"

static int on_get_user(void* result, int num_cols, char** row, char** cols) {
	char* password = (char*)result;
	if(strcmp(cols[2], "password") == 0) {
		strcpy(password, row[2]);
	} else {
		strcpy(password, "");
	}
	return 0;
}

int login(char* username, char* password) {
	printf("INFO: login() is started\n");

	char sql[MAX_STRING_LENGTH_SQL] = "SELECT * FROM users WHERE username = '";
	strcat(sql, username);
	strcat(sql, "';");
	char stored_password[MAX_STRING_LENGTH_TOKEN] = "";
	select_query(sql, on_get_user, &stored_password);

	// if username is not exist
	if(strlen(stored_password) == 0) {
		printf("Login faild: Username is not exist\n");
		return 0;
	}

	// if password is not matched
	if(strcmp(stored_password, password) != 0) {
		printf("Login faild: Password is not matched\n");
		return 0;
	}

	return 1;
}