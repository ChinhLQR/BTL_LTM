#include "helper.h"
#include <sys/types.h>
#include <sys/socket.h>
#include <string.h>
#include <stdio.h>

int send_message(int client, char* message) {
	ssize_t sent_length;
	sent_length = send(client, message, strlen(message), 0);
	if((int)sent_length > 0) {
		printf("INFO: Sent %d byte(s): \"%s\"\n", (int)(sent_length), message);
	}
	return (int)sent_length;
}