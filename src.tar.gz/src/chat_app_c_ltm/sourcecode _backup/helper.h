#ifndef _HELPER_H_
#define _HELPER_H_

int send_message(int client, char* message);

#endif