# Description
* This is repo for App Chat using Socket Programming in C Language.
* 20171
* Teacher: LinhTD

#Memeber
|STT 	|Full Name 			|MSSV 		|
|-------|-------------------|-----------|
|1		|Giáp Minh Cương	|20140539	|