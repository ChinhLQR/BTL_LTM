#include <stdio.h>
#include <stdlib.h>
#include <glib.h>
#include <gtk/gtk.h>


#include <string.h>
#include <ctype.h>

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>

#define SERVER_IP "127.0.0.1"
#define SERVER_PORT 8484
#define MESSAGE_LENGTH 300
#define MAXLINE 4096


GtkBuilder      *builder; 

//Cua so login
GtkWidget       *entry_name;
GtkWidget       *entry_pass;
GtkWidget       *label;

//Cua so chat
GtkWidget       *view_chat;
GtkWidget       *entry_chat;
GtkWidget	*entry_addfriend;
GtkTextIter iter;
GtkTextBuffer *buffer;

char username[20];
int server = -1;

void signup();
void login();

//send
int send_message(int server, char* message) {
  ssize_t sent_length;
  sent_length = send(server, message, strlen(message), 0);
  return (int)sent_length;
}

//recv
int recv_message(int server, char* message) {
  ssize_t sent_length;
  sent_length = recv(server, message, strlen(message), 0);
  printf("INFO: Sent %d byte(s)\n", (int)(sent_length));
  return (int)sent_length;
}


//connect to server
int connect_server(char* server_ip, int port) {
    // 1 Tao socket
    server = socket(AF_INET, SOCK_STREAM, 0);
    if (server < 0) {
      printf("ERROR: socket()!\n");
      return 1;
    }
  
    // 2 Connect
    // 2.1 Tao server_address
    struct sockaddr_in server_address;
    server_address.sin_family = AF_INET;
    // cach 2 su dung inet_addr. Method nay khong duoc khuyen khich
    //server_address.sin_addr.s_addr = inet_addr(server_ip);
    inet_aton(server_ip, &(server_address.sin_addr));
    server_address.sin_port = htons(port);
  
    // 2.2 Connect
    int connect_result = connect(server, (struct sockaddr*)&server_address, sizeof(server_address));
    if (connect_result < 0) {
      printf("ERROR: connect()\n");
    }
    return server;
  }



int main(int argc, char *argv[])
{
    
    GtkWidget       *window;
    

    int server = connect_server("127.0.0.1", 8484);
 
    gtk_init(&argc, &argv);
 
    builder = gtk_builder_new();
    gtk_builder_add_from_file (builder, "window_main.glade", NULL);
 
    //Cua so login
    window = GTK_WIDGET(gtk_builder_get_object(builder, "Window_Login"));
    label = GTK_WIDGET(gtk_builder_get_object(builder, "Label_Status"));
    entry_name = GTK_WIDGET(gtk_builder_get_object(builder,"Entry_Name"));
    entry_pass = GTK_WIDGET(gtk_builder_get_object(builder,"Entry_Pass"));

    //Cua so chat
    view_chat = GTK_WIDGET(gtk_builder_get_object(builder,"View_Chat"));
    entry_chat = GTK_WIDGET(gtk_builder_get_object(builder,"Entry_Chat"));
    entry_addfriend = GTK_WIDGET(gtk_builder_get_object(builder,"Entry_AddFriend"));
    gtk_builder_connect_signals(builder, NULL);
	


    g_object_unref(builder);
 
    gtk_widget_show(window);                
    gtk_main();
 
    return 0;
}
 
// called when window is closed
void on_window_main_destroy()
{   
	int bytes_recv;
 	char sendline[MAXLINE], recvline[MAXLINE];
	char head[60]="LGOT|";		
    
   	strcat(head,username);
	strcat(head,"\0");
	send(server, head, strlen(head), 0);
	bytes_recv = recv(server, head, MAXLINE,0);
  	//recvline[bytes_recv]='\0';
  	//printf("%s\n",recvline);
	strcpy(username,"");
  	gtk_main_quit();
	
}


//Xu li Login
void on_Btn_Login_clicked(GtkButton *button,GtkWindow *window_login)
{
    GtkBuilder      *builder; 
    GtkWidget       *window;
    builder = gtk_builder_new();

/*if(g_utf8_collate (gtk_entry_get_text(entry_name),"hello")==0&&g_utf8_collate (gtk_entry_get_text(entry_pass),"bye")==0)
    {
    gtk_builder_add_from_file (builder, "window_main.glade", NULL); 
    gtk_widget_hide(window_login);
    window = GTK_WIDGET(gtk_builder_get_object(builder, "Window_Chat"));
    //xam
    gtk_builder_connect_signals(builder, NULL);
    view_chat = GTK_WIDGET(gtk_builder_get_object(builder,"View_Chat"));
    entry_chat = GTK_WIDGET(gtk_builder_get_object(builder,"Entry_Chat"));


    buffer = gtk_text_view_get_buffer(GTK_TEXT_VIEW(view_chat));
    gtk_text_buffer_get_iter_at_offset(buffer, &iter, 0);
    //g_object_unref(builder);
    //endxam
    gtk_widget_show(window);
    }
else
    {
    gtk_label_set_text(GTK_LABEL(label),"Login Failed , try again !");
    reset_name_pass();
    }*/
 char user[20],pass[20];
  char head[60]="LGIN|";
  char* p;
  char sendline[MAXLINE], recvline[MAXLINE];
  int bytes_recv;
    strcat(username,gtk_entry_get_text(entry_name));
    strcat(head,gtk_entry_get_text(entry_name));
    strcat(head,"|");
    strcat(head,gtk_entry_get_text(entry_pass));
    strcat(head,"\0");
  strcpy(sendline,head);
  send(server, sendline, strlen(sendline), 0);
  bytes_recv = recv(server, recvline, MAXLINE,0);
  recvline[bytes_recv]='\0';
  printf("%s\n",recvline);
  p = strtok(recvline, "|");
  if (strcmp(p,"201")==0)
  {
    gtk_builder_add_from_file (builder, "window_main.glade", NULL); 
    gtk_widget_hide(window_login);
    window = GTK_WIDGET(gtk_builder_get_object(builder, "Window_Chat"));
    //xam
    gtk_builder_connect_signals(builder, NULL);
    view_chat = GTK_WIDGET(gtk_builder_get_object(builder,"View_Chat"));
    entry_chat = GTK_WIDGET(gtk_builder_get_object(builder,"Entry_Chat"));
    


    buffer = gtk_text_view_get_buffer(GTK_TEXT_VIEW(view_chat));
    gtk_text_buffer_get_iter_at_offset(buffer, &iter, 0);
    //g_object_unref(builder);
    //endxam
    gtk_widget_show(window);
    printf("login success\n");
  }
  if (strcmp(p,"205")==0)
  {
	gtk_label_set_text(GTK_LABEL(label),"Login Failed , try again !");
    reset_name_pass();
    printf("login error\n");
  }


    //
}

//Xu li SignUp
void on_Btn_SignUp_clicked()
{   
 
    /*
    if(gtk_entry_get_text_length(entry_name)<5)
    {
        gtk_label_set_text(GTK_LABEL(label),"User name too short,at least 5 characters");
        reset_name_pass();
    }
    else if(gtk_entry_get_text_length(entry_pass)<5)
    {
        gtk_label_set_text(GTK_LABEL(label),"Password too short,at least 5 characters");
        reset_name_pass();
    }
    else if(g_utf8_collate (gtk_entry_get_text(entry_name),"hello")==0 )
    {
        gtk_label_set_text(GTK_LABEL(label),"User name existed, please try again");
        reset_name_pass();
    }
    else
    gtk_label_set_text(GTK_LABEL(label),"Signed Up!");
    
*/

    


    char user[20],pass[20];
    char head[60]="SGNU|";
    char* p;
    char sendline[MAXLINE], recvline[MAXLINE];
    int bytes_recv;
    strcat(head,gtk_entry_get_text(entry_name));
    strcat(head,"|");
    strcat(head,gtk_entry_get_text(entry_pass));
    strcat(head,"\0");
    strcpy(sendline,head);
     send(server, sendline, strlen(sendline), 0);
    printf("%s\n",sendline);
    bytes_recv = recv(server, recvline, MAXLINE,0);

    recvline[bytes_recv]='\0';

    p = strtok(recvline, "|");
    
    printf("lbl: %s\n",recvline);
    printf("%s\n",p);
    gtk_label_set_text(GTK_LABEL(label),recvline);


/*

    
    if (strcmp(p,"101")==0)
    {
      //printf("sigup success\n");
      gtk_label_set_text(GTK_LABEL(label),"Signed Up success!");
    }
    if (strcmp(p,"102")==0)
    {
      //printf("sigup error\n");
      gtk_label_set_text(GTK_LABEL(label),"SignUp error");
      reset_name_pass();
    }
  */  
}


void on_Btn_Send_clicked()
{

    //de day thi se bi ko xuong dong ma len nguoc, nen vut len tren khi vua chuyen window
   // GtkTextIter iter;
    //GtkTextBuffer *buffer;
   // buffer = gtk_text_view_get_buffer(GTK_TEXT_VIEW(view_chat));
    //gtk_text_buffer_get_iter_at_offset(buffer, &iter, 0);

    gtk_text_buffer_insert(buffer,&iter,"you: ",-1);
    gtk_text_buffer_insert(buffer,&iter,gtk_entry_get_text(entry_chat),-1);
    gtk_text_buffer_insert(buffer,&iter,"\n",-1);
    gtk_entry_set_text(entry_chat,"");
    



   gtk_text_view_set_buffer(view_chat,buffer);
}

void on_Btn_AddFriend_clicked()
{
	
    char head[60]="FREQ|";
    char* p;
    char sendline[MAXLINE], recvline[MAXLINE];
    int bytes_recv;
    strcat(head,username);
strcat(head,"|");
    strcat(head,gtk_entry_get_text(entry_addfriend));

    strcat(head,"\0");
    strcpy(sendline,head);
     send(server, sendline, strlen(sendline), 0);
   // printf("%s\n",sendline);
   // bytes_recv = recv(server, recvline, MAXLINE,0);

   // recvline[bytes_recv]='\0';
}

void reset_name_pass()
{
    gtk_entry_set_text(entry_name,"");
    gtk_entry_set_text(entry_pass,"");
}

